package org.miray.videocompressor

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.media3.common.MediaItem
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import androidx.media3.transformer.EncoderFactory
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.Transformer.Listener
import androidx.media3.common.MimeTypes
import java.io.File

class MainActivity : ComponentActivity() {
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var compressButton: Button
    private lateinit var quality: Spinner
    private var selectedUri: Uri? = null
    private var transformer: Transformer? = null

    private val pickVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            selectedUri = uri
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            status.text = "تم اختيار الفيديو بنجاح"
            compressButton.isEnabled = true
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(93, 7, 51)
        window.navigationBarColor = android.graphics.Color.rgb(93, 7, 51)
        val burgundy = android.graphics.Color.rgb(93, 7, 51)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 24)
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(android.graphics.Color.rgb(250, 247, 248))
        }
        val title = TextView(this).apply {
            text = "MIRAY\nضغط الفيديو"
            textSize = 28f
            gravity = Gravity.CENTER
            setTextColor(burgundy)
            setPadding(0, 16, 0, 10)
        }
        val subtitle = TextView(this).apply {
            text = "ضغط الفيديو على الهاتف مع الحفاظ على جودة مناسبة"
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.DKGRAY)
            setPadding(0, 0, 0, 28)
        }
        val pickButton = Button(this).apply {
            text = "اختيار فيديو"
            setOnClickListener { pickVideo.launch(arrayOf("video/*")) }
        }
        quality = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("ضغط قوي — حجم أصغر", "متوازن — موصى به", "جودة عالية"))
        }
        compressButton = Button(this).apply {
            text = "بدء الضغط"
            isEnabled = false
            setOnClickListener { startCompression() }
        }
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
            visibility = View.GONE
        }
        status = TextView(this).apply {
            text = "اختر فيديو للبدء"
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.DKGRAY)
            setPadding(0, 18, 0, 18)
        }
        val note = TextView(this).apply {
            text = "تُحفظ النسخة المضغوطة في مجلد Movies/Miray.\nتعتمد السرعة والنتيجة على الهاتف والفيديو الأصلي."
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.GRAY)
            setPadding(0, 24, 0, 0)
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        root.addView(subtitle, LinearLayout.LayoutParams(-1, -2))
        root.addView(pickButton, LinearLayout.LayoutParams(-1, -2))
        root.addView(quality, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 12 })
        root.addView(compressButton, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 12 })
        root.addView(progress, LinearLayout.LayoutParams(-1, 10).apply { topMargin = 22 })
        root.addView(status, LinearLayout.LayoutParams(-1, -2))
        root.addView(note, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }

    private fun startCompression() {
        val input = selectedUri ?: return
        try {
            val dir = File(getExternalFilesDir(android.os.Environment.DIRECTORY_MOVIES), "Miray")
            if (!dir.exists()) dir.mkdirs()
            val out = File(dir, "Miray_${System.currentTimeMillis()}.mp4")
            val bitrate = when (quality.selectedItemPosition) {
                0 -> 900_000
                2 -> 3_500_000
                else -> 1_800_000
            }
            val encoderFactory: EncoderFactory = DefaultEncoderFactory.Builder(this)
                .setRequestedVideoEncoderSettings(
                    VideoEncoderSettings.Builder().setBitrate(bitrate).build()
                ).build()
            val builder = Transformer.Builder(this)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .setEncoderFactory(encoderFactory)
                .addListener(object : Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        runOnUiThread {
                            progress.visibility = View.GONE
                            progress.progress = 100
                            compressButton.isEnabled = true
                            status.text = "اكتمل الضغط بنجاح\n${out.absolutePath}\nالحجم: ${out.length()/1024/1024} MB"
                            Toast.makeText(this@MainActivity, "تم حفظ الفيديو المضغوط", Toast.LENGTH_LONG).show()
                        }
                    }
                    override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                        runOnUiThread {
                            progress.visibility = View.GONE
                            compressButton.isEnabled = true
                            status.text = "تعذر ضغط الفيديو: ${exportException.localizedMessage ?: "خطأ غير معروف"}"
                        }
                    }
                })
            transformer = builder.build()
            compressButton.isEnabled = false
            progress.visibility = View.VISIBLE
            progress.isIndeterminate = true
            status.text = "جارٍ ضغط الفيديو… قد يستغرق ذلك بعض الوقت"
            transformer!!.start(EditedMediaItem.Builder(MediaItem.fromUri(input)).build(), out.absolutePath)
        } catch (e: Exception) {
            compressButton.isEnabled = true
            progress.visibility = View.GONE
            status.text = "حدث خطأ: ${e.localizedMessage ?: e.javaClass.simpleName}"
        }
    }
}
